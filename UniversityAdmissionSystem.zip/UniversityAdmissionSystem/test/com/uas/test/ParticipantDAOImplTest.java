package com.uas.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.uas.bean.ParticipantBean;
import com.uas.dao.ISystemDAO;
import com.uas.dao.SystemDAOImpl;
import com.uas.exception.UserException;

public class ParticipantDAOImplTest {

	ISystemDAO participantDao;
	
	@Before
	public void setUp() throws Exception {
		participantDao = new SystemDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		participantDao = null;
	}

	@Test
	public void testAddParticipant() {
		ParticipantBean participantBean = new ParticipantBean();
		participantBean.setRollNo("1046");
		participantBean.setEmailId("az@az.com");
		try {
			boolean isInserted = participantDao.addParticipant(participantBean, 1046, "PS123");
			assertTrue(isInserted);
		} catch (UserException e) {
			assertEquals("Unable to persist", e.getMessage());
		}
	}

}
