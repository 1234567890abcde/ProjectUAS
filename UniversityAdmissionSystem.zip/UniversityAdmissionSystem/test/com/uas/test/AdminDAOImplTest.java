package com.uas.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Date;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.uas.bean.ApplicantBean;
import com.uas.bean.ProgramsOfferedBean;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.bean.UserBean;
import com.uas.bean.UserRole;
import com.uas.dao.ISystemDAO;
import com.uas.dao.SystemDAOImpl;
import com.uas.exception.UserException;

public class AdminDAOImplTest {

	ISystemDAO adminDao;
	
	@Before
	public void setUp() throws Exception {
		adminDao = new SystemDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		adminDao = null;
	}

	@Test
	public void testIsAuthenticated() {
		UserBean userBean = new UserBean("ji95","pass",UserRole.ADMIN);
		try {
			UserBean users = adminDao.isAuthenticated(userBean);
			assertTrue(users!=null);
		} catch (UserException e) {
			assertEquals("Invalid Login Credentials", e.getMessage());
		}
	}

	@Test
	public void testDeleteProgramOffered() {
		try {
			boolean isDeleted = adminDao.deleteProgramOffered("B.COM");
			assertTrue(isDeleted);
		} catch (UserException e) {
			assertEquals("No program exist with this name : B.COM", e.getMessage());
		}
	}

	@Test
	public void testAddProgramOffered() {
		ProgramsOfferedBean programsOfferedBean = new ProgramsOfferedBean("MTECH","Post Graduate","55",(byte)25,"Masters");
		try {
			boolean isInserted = adminDao.addProgramOffered(programsOfferedBean);
			assertTrue(isInserted);
		} catch (UserException e) {
			assertEquals("Invalid Data", e.getMessage());
		}
	}

	@Test
	public void testViewProgramsScheduled() {
		try {
			List<ProgramsScheduledBean> programScheduledList = adminDao.viewProgramsScheduled();
			assertTrue(programScheduledList.size()>0);
		} catch (UserException e) {
			assertEquals("No data found", e.getMessage());
		}
	}

	@Test
	public void testDeleteProgramScheduled() {
		try {
			boolean isDeleted = adminDao.deleteProgramScheduled("PS456");
			assertTrue(isDeleted);
		} catch (UserException e) {
			assertEquals("No program exist with this id : PS456", e.getMessage());
		}
	}

	@Test
	public void testAddProgramScheduled() {
		ProgramsScheduledBean programsScheduledBean = new ProgramsScheduledBean("PS456","Mumbai","Maharastra",302022,new Date(),new Date(),(byte)25);
		try {
			boolean isInserted = adminDao.addProgramScheduled(programsScheduledBean);
			assertTrue(isInserted);
		} catch (UserException e) {
			assertEquals("Invalid Data", e.getMessage());
		}
	}

	@Test
	public void testViewListOfApplicants() {
		try {
			List<ApplicantBean> applicantList = adminDao.viewListOfApplicants();
			assertTrue(applicantList.size()>0);
		} catch (UserException e) {
			assertEquals("No data found", e.getMessage());
		}
	}

}
