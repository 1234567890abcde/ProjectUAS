package com.uas.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Date;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.uas.bean.ApplicantBean;
import com.uas.bean.Application_Status;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.dao.ISystemDAO;
import com.uas.dao.SystemDAOImpl;
import com.uas.exception.UserException;

public class ApplicantDAOImplTest {

	ISystemDAO applicantDao;
	
	@Before
	public void setUp() throws Exception {
		applicantDao = new SystemDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		applicantDao = null;
	}

	@Test
	public void testViewPrograms() {
		try {
			List<ProgramsScheduledBean> programScheduledList = applicantDao.viewPrograms();
			assertTrue(programScheduledList.size()>0);
		} catch (UserException e) {
			assertEquals("No data found", e.getMessage());
		}
	}

	@Test
	public void testInsertApplicant() {
		ApplicantBean applicantBean = new ApplicantBean("Abhay",new Date(),"Graduate",87,"Developer","non@non.com");
		try {
			int applicantId = applicantDao.insertApplicant(applicantBean, "PS123");
			assertTrue(applicantId!=0);
		} catch (UserException e) {
			assertEquals("Unable to persist ", e.getMessage());
		}
	}

	@Test
	public void testViewStatus() {
		try {
			Application_Status status = applicantDao.viewStatus(1060);
			assertTrue(status!=null);
		} catch (UserException e) {
			assertEquals("No applicant found with this id : 1060", e.getMessage());
		}
	}

	@Test
	public void testGetApplicantInfo() {
		try {
			String[] info  = new String[2];
			info = applicantDao.getApplicantInfo(1060);
			assertTrue(info!=null);
		} catch (UserException e) {
			assertEquals("No applicant found with id : 1060", e.getMessage());
		}
	}

}
