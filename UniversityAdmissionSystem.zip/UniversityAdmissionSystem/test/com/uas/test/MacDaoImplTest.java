package com.uas.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Date;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.uas.bean.ApplicantBean;
import com.uas.bean.Application_Status;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.bean.UserBean;
import com.uas.bean.UserRole;
import com.uas.dao.ISystemDAO;
import com.uas.dao.SystemDAOImpl;
import com.uas.exception.UserException;

public class MacDaoImplTest {

	ISystemDAO macDaoImpl;
	@Before
	public void setUp() throws Exception {
		macDaoImpl = new SystemDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		macDaoImpl = null;
	}

	@Test
	public void testIsAuthenticated() {
		UserBean userBean = new UserBean("Guna4","pass",UserRole.MAC);
		try {
			UserBean users = macDaoImpl.isAuthenticated(userBean);
			assertTrue(users!=null);
		} catch (UserException e) {
			assertEquals("Invalid Login Credentials", e.getMessage());
		}
	}
	

	@Test
	public void testViewListOfApplicants() {
		try {
			List<ApplicantBean> applicantBean = macDaoImpl.viewListOfApplicants("PS123");
			assertTrue(applicantBean.size()>0);
		} catch (UserException e) {
			assertEquals("No Applicant Exist", e.getMessage());
		}
	}

	@Test
	public void testScheduleInterviewDate() {
		try {
			boolean isUpdated = macDaoImpl.scheduleInterviewDate(1042, Application_Status.ACCEPTED,new Date() );
			assertTrue(isUpdated);
		} catch (UserException e) {
			assertEquals("No Applicant exist with this Id : 1042", e.getMessage());
		}
	}

	@Test
	public void testGetAllProgramsSchedule() {
		try {
			List<ProgramsScheduledBean> programList = macDaoImpl.getAllProgramsSchedule();
			assertTrue(programList.size()>0);
		} catch (UserException e) {
			assertEquals("No Program Exists ", e.getMessage());
		}
	}

}
