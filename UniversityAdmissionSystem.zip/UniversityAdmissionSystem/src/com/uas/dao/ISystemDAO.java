package com.uas.dao;

import java.util.Date;
import java.util.List;

import com.uas.bean.ApplicantBean;
import com.uas.bean.Application_Status;
import com.uas.bean.ParticipantBean;
import com.uas.bean.ProgramsOfferedBean;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.bean.UserBean;
import com.uas.exception.UserException;

public interface ISystemDAO {
	
	public UserBean isAuthenticated(UserBean userBean) throws UserException;
	
	/*Admin*/

	//Programs Offered Features
	public boolean deleteProgramOffered(String programName) throws UserException;
	public boolean addProgramOffered(ProgramsOfferedBean programsOfferedBean) throws UserException;
	
	//Programs Offered Features
	public List<ProgramsScheduledBean> viewProgramsScheduled() throws UserException;
	public boolean deleteProgramScheduled(String programId) throws UserException;
	public boolean addProgramScheduled(ProgramsScheduledBean programsScheduledBean) throws UserException;
	
	//view applicant for status
	public List<ApplicantBean> viewListOfApplicants() throws UserException;
	
	/*-------------------------------------------------------------------------------------------------------*/
	
	/*MAC*/
	
	//view applicant list for specific programs offered
	public List<ApplicantBean> viewListOfApplicants(String Scheduled_program_id) throws UserException;
	
	//update status of applicant
	public boolean scheduleInterviewDate(int applicationId, Application_Status status, Date dateOfInterview) throws UserException;
	
	public List<ProgramsScheduledBean> getAllProgramsSchedule() throws UserException;
	
	/*-------------------------------------------------------------------------------------------------------*/
	
	
	/*Applicant*/
	public List<ProgramsScheduledBean> viewPrograms() throws UserException;
	public int insertApplicant(ApplicantBean applicantBean,String programId) throws UserException;
	public Application_Status viewStatus(int applicantId) throws UserException;
	public String[] getApplicantInfo(int applicationId) throws UserException;
	/*-------------------------------------------------------------------------------------------------------*/
	
	
	/*Participant*/
	public boolean addParticipant(ParticipantBean participantBean, int applicationId, String scheduleId) throws UserException;
	/*-------------------------------------------------------------------------------------------------------*/
}
