package com.uas.dao;

import java.util.Date;
import java.util.List;

import com.uas.bean.ApplicantBean;
import com.uas.bean.Application_Status;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.bean.UserBean;
import com.uas.exception.UserException;


public interface IMacDAO {
	
	public UserBean isAuthenticated(UserBean userBean) throws UserException;
	
	//view applicant list for specific programs offered
	public List<ApplicantBean> viewListOfApplicants(String Scheduled_program_id) throws UserException;
	
	//update status of applicant
	public boolean scheduleInterviewDate(int applicationId, Application_Status status, Date dateOfInterview) throws UserException;
	
	public List<ProgramsScheduledBean> getAllProgramsSchedule() throws UserException;

}