package com.uas.dao;

/*
Roll_no VARCHAR2(5) UNIQUE NOT NULL, 
email_id VARCHAR2(20) PRIMARY KEY,
Application_id REFERENCES APPLICATION(Application_id) , 
Scheduled_program_id VARCHAR2(5) REFERENCES Programs_Scheduled(Scheduled_program_id)
*/

public interface ParticipantQueryMapper {
	public static final String ADD_PARTICIPANT = "INSERT INTO Participant VALUES(?,?,?,?)";
}
