package com.uas.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.uas.bean.ApplicantBean;
import com.uas.bean.Application_Status;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.bean.UserBean;
import com.uas.exception.UserException;

/**
 *  Author : Jitesh, Harshita, Sree Ramya
 *  Class Name : MacDaoImpl 
 *  Package :com.uas.dao 
 *  Date : December 09, 2017
 *  Version : 1.0
 */
@Repository
@Transactional
public class MacDaoImpl implements IMacDAO {

	@PersistenceContext
	private EntityManager entityManager;
	
	/**************************************************************
	 * - Method Name : isAuthenticated(UserBean userBean) 
	 * - Input Parameters : UserBean userBean 
	 * - Return Type :boolean 
	 * - Throws : UserException 
	 * - Author : Jitesh, Harshita, Sree Ramya
	 * - Creation Date : December 09, 2017 
	 * - Description : Authenticate the user
	 * - Version : 1.0.1
	 *************************************************************/
	@Override
	public UserBean isAuthenticated(UserBean userBean) throws UserException {
		UserBean users = new UserBean();
		try {			
			users = entityManager.find(UserBean.class,userBean.getLoginId());
		} catch (Exception e) {
			throw new UserException("Invalid Login Credentials");
		}		
		return users;
	}

	/**************************************************************
	 * - Method Name : viewListOfApplicants(String Scheduled_program_id)
	 * - Input Parameters : String Scheduled_program_id 
	 * - Return Type :List<ApplicantBean>
	 * - Throws : UserException 
	 * - Author : Jitesh, Harshita, Sree Ramya
	 * - Creation Date : December 09, 2017 
	 * - Description : Retrieve list of applicants based on scheduled program ID
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public List<ApplicantBean> viewListOfApplicants(String Scheduled_program_id)
			throws UserException{
		List<ApplicantBean> applicantBean = null;
		try {
			TypedQuery<ApplicantBean> query = entityManager.createQuery("FROM ApplicantBean WHERE Scheduled_program_id=?", ApplicantBean.class);
			query.setParameter(1, Scheduled_program_id);
			applicantBean = query.getResultList();
		} catch (Exception e) {
			throw new UserException("No Applicant Exist");
		}
		return applicantBean;
		
	}

	/**************************************************************
	 * - Method Name : scheduleInterviewDate(int applicationId,Application_Status status, LocalDate dateOfInterview)
	 * - Input Parameters : int applicationId,Application_Status status, LocalDate dateOfInterview
	 * - Return Type :boolean
	 * - Throws : UserException 
	 * - Author : Jitesh, Harshita, Sree Ramya
	 * - Creation Date : December 09, 2017 
	 * - Description : update status of applicant and assign date of interview to the applicant
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public boolean scheduleInterviewDate(int applicationId,Application_Status status, Date dateOfInterview)
			throws UserException {
		boolean isUpdated = false;
		try {
			ApplicantBean applicantBean = entityManager.find(ApplicantBean.class, applicationId);
			applicantBean.setStatus(status);
			applicantBean.setDateOfInterview(dateOfInterview);
			entityManager.merge(applicantBean);
			isUpdated = true;
		} catch (Exception e) {
			throw new UserException("No Applicant exist with this Id : "+applicationId);
		}
		return isUpdated;
	}

	/**************************************************************
	 * - Method Name : getAllProgramsSchedule()
	 * - Input Parameters :
	 * - Return Type :List<ProgramsScheduledBean>
	 * - Throws : UserException 
	 * - Author : Jitesh, Harshita, Sree Ramya
	 * - Creation Date : December 09, 2017 
	 * - Description : retrieve all programs scheduled
	 * - Version : 1.0
	 *************************************************************/

	@Override
	public List<ProgramsScheduledBean> getAllProgramsSchedule()
			throws UserException {
		List<ProgramsScheduledBean> programList = null;
		try {
			TypedQuery<ProgramsScheduledBean> query = entityManager.createQuery("FROM ProgramsScheduledBean",ProgramsScheduledBean.class);
			programList = query.getResultList();
		} catch (Exception e) {
			throw new UserException("No Program Exists ");
		}
		return programList;
	}

}