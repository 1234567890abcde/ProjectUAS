package com.uas.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.uas.bean.ApplicantBean;
import com.uas.bean.ProgramsOfferedBean;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.bean.UserBean;
import com.uas.exception.UserException;

/**
 *  Author 		: Gaurav, Pratyush, Arjun
 *  Class Name 	: AdminDAOImpl 
 *  Package 	: com.uas.dao 
 *  Date 		: December 09, 2017
 *  Version		: 1.0.1
 */
@Repository
@Transactional
public class AdminDAOImpl implements IAdminDAO {

	@PersistenceContext
	private EntityManager entityManager;
	
	/**************************************************************
	 * - Method Name : isAuthenticated(UserBean userBean) 
	 * - Input Parameters :  UserBean userBean
	 * - Return Type :boolean 
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 09, 2017 
	 * - Description : Authenticate the user
	 * - Version	: 1.0.1
	 *************************************************************/
	@Override
	public UserBean isAuthenticated(UserBean userBean) throws UserException {
		UserBean users = null;
		try {
			users = entityManager.find(UserBean.class, userBean.getLoginId());
		} catch (Exception e) {
			throw new UserException("Invalid Login Credentials");
		}		
		return users;
	}

	/****************************************************************************
	 * - Method Name 		: deleteProgramOffered(String programName)
	 * - Input Parameters 	: String programName
	 * - Return Type 		: boolean 
	 * - Throws 			: UserException 
	 * - Author 			: Gaurav, Pratyush, Arjun
	 * - Creation Date 		: December 09, 2017 
	 * - Description 		: delete program offered according to program name
	 * - Version			: 1.0.1
	 ****************************************************************************/
	@Override
	public boolean deleteProgramOffered(String programName)
			throws UserException {

		ProgramsOfferedBean programsOfferedBean = null;
		boolean isDeleted = false;
		try {
			programsOfferedBean = entityManager.find(ProgramsOfferedBean.class, programName);
			entityManager.remove(programsOfferedBean);
			isDeleted=true;
		} catch (Exception e) {
			throw new UserException("No program exist with this name : "+programName);
		}
		
		return isDeleted;
	}

	/**************************************************************
	 * - Method Name : addProgramOffered(ProgramsOfferedBean programsOfferedBean)
	 * - Input Parameters :  ProgramsOfferedBean programsOfferedBean
	 * - Return Type :boolean 
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 09, 2017 
	 * - Description : insert program offered
	 * - Version	: 1.0.1 
	 *************************************************************/
	@Override
	public boolean addProgramOffered(ProgramsOfferedBean programsOfferedBean)
			throws UserException {
		boolean isInserted = false;
		try {
			entityManager.persist(programsOfferedBean);
			entityManager.flush();
			isInserted = true;
		} catch (Exception e) {
			throw new UserException("Invalid Data");
		}
		return isInserted;
	}

	/**************************************************************
	 * - Method Name : viewProgramsScheduled()
	 * - Input Parameters :  
	 * - Return Type : List<ProgramsScheduledBean>
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 09, 2017 
	 * - Description : Retrieve all programs scheduled
	 * - Version : 1.0.1
	 *************************************************************/
	@Override
	public List<ProgramsScheduledBean> viewProgramsScheduled()
			throws UserException {
		List<ProgramsScheduledBean> programScheduledList = null;
		try {
			TypedQuery<ProgramsScheduledBean> query = entityManager.createQuery("FROM ProgramsScheduledBean", ProgramsScheduledBean.class);
			programScheduledList = query.getResultList();
		} catch (Exception e) {
			throw new UserException("No data found");
		}
		
		
		return programScheduledList;
	}

	/**************************************************************
	 * - Method Name : deleteProgramScheduled(String programId)
	 * - Input Parameters :  String programId
	 * - Return Type : boolean
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 09, 2017 
	 * - Description : delete programs scheduled according to program ID
	 * - Version : 1.0.1
	 *************************************************************/
	@Override
	public boolean deleteProgramScheduled(String programId)
			throws UserException {

		ProgramsScheduledBean programsScheduledBean = null;
		boolean isDeleted = false;
		try {
			programsScheduledBean = entityManager.find(ProgramsScheduledBean.class, programId);
			entityManager.remove(programsScheduledBean);
			isDeleted=true;
		} catch (Exception e) {
			throw new UserException("No program exist with this id : "+programId);
		}
		
		return isDeleted;

	}

	/**************************************************************
	 * - Method Name : addProgramScheduled(ProgramsScheduledBean programsScheduledBean)
	 * - Input Parameters :  ProgramsScheduledBean programsScheduledBean
	 * - Return Type : boolean
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 09, 2017 
	 * - Description : insert new programs scheduled
	 * - Version : 1.0.1 
	 *************************************************************/
	@Override
	public boolean addProgramScheduled(
			ProgramsScheduledBean programsScheduledBean) throws UserException {
		boolean isInserted = false;
		try {
			entityManager.persist(programsScheduledBean);
			entityManager.flush();
			isInserted = true;
		} catch (Exception e) {
			throw new UserException("Invalid Data");
		}
		return isInserted;
	}

	/**************************************************************
	 * - Method Name : viewListOfApplicants()
	 * - Input Parameters :  
	 * - Return Type : List<ApplicantBean>
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 09, 2017 
	 * - Description : Retrieve list of applicants
	 * - Version : 1.0.1
	 *************************************************************/
	@Override
	public List<ApplicantBean> viewListOfApplicants() throws UserException {

		List<ApplicantBean> applicantList = null;
		try {
			TypedQuery<ApplicantBean> query = entityManager.createQuery("FROM ApplicantBean", ApplicantBean.class);
			applicantList = query.getResultList();
		} catch (Exception e) {
			throw new UserException("No data found");
		}
		
	
		return applicantList;
	}

}