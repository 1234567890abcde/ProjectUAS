package com.uas.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.uas.bean.ApplicantBean;
import com.uas.bean.Application_Status;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.exception.UserException;

/**
 *  Author : KAMAL, GUNJAN
 *  Class Name : ApplicantDAOImpl 
 *  Package :com.uas.dao 
 *  Date : December 09, 2017
 *  Version : 1.0
 */

@Repository
@Transactional
public class ApplicantDAOImpl implements IApplicantDAO {

	@PersistenceContext
	private EntityManager entityManager;
	
	/**************************************************************
	 * - Method Name : viewPrograms() 
	 * - Input Parameters :  
	 * - Return Type :List<ProgramsScheduledBean> 
	 * - Throws : UserException 
	 * - Author : KAMAL, GUNJAN
	 * - Creation Date : December 09, 2017 
	 * - Description : Retrieval of programs offered along with programs scheduled
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public List<ProgramsScheduledBean> viewPrograms() throws UserException {
		List<ProgramsScheduledBean> programScheduledList = null;
		try {
			TypedQuery<ProgramsScheduledBean> query = entityManager.createQuery("FROM ProgramsScheduledBean", ProgramsScheduledBean.class);
			programScheduledList = query.getResultList();
		} catch (Exception e) {
			throw new UserException("No data found");
		}
		
		return programScheduledList;
	}

	
	/**************************************************************
	 * - Method Name : insertApplicant(ApplicantBean applicantBean,String programName) 
	 * - Input Parameters :  ApplicantBean, String
	 * - Return Type :int 
	 * - Throws : UserException 
	 * - Author : KAMAL, GUNJAN
	 * - Creation Date : December 09, 2017 
	 * - Description : insert new applicant details
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public int insertApplicant(ApplicantBean applicantBean,String programId) throws UserException {
		int id = 0;
		try {
			TypedQuery<ProgramsScheduledBean> query = entityManager.createQuery("FROM ProgramsScheduledBean WHERE Scheduled_program_id=?",ProgramsScheduledBean.class);
			query.setParameter(1, programId);
			ProgramsScheduledBean programsScheduledBean  = query.getSingleResult();
			applicantBean.setProgramsScheduledBean(programsScheduledBean);
			entityManager.persist(applicantBean);
			entityManager.flush();
			id = applicantBean.getApplicationId();
		} catch (Exception e) {
			throw new UserException("Unable to persist ");
		}
		return id;
	}

	
	/**************************************************************
	 * - Method Name : viewStatus(int applicantId) 
	 * - Input Parameters :  int
	 * - Return Type :Application_Status 
	 * - Throws : UserException 
	 * - Author : KAMAL, GUNJAN
	 * - Creation Date : December 09, 2017 
	 * - Description : Retrieval of status of an applicant according to applicantId
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public Application_Status viewStatus(int applicantId) throws UserException {
		
		Application_Status status = null;
		
		try {
			ApplicantBean applicantBean = entityManager.find(ApplicantBean.class, applicantId);
			status = applicantBean.getStatus();
		} catch (Exception e) {
			throw new UserException("No applicant found with this id : "+applicantId);
		}
		return status;
	}


	/**************************************************************
	 * - Method Name : getApplicantInfo(int applicationId) 
	 * - Input Parameters :  int applicationId
	 * - Return Type :String[] 
	 * - Throws : UserException 
	 * - Author : KAMAL, GUNJAN
	 * - Creation Date : December 09, 2017 
	 * - Description : Retrieval of email id and scheduled program id of an applicant according to applicantId
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public String[] getApplicantInfo(int applicationId) throws UserException {
		
		String[] info  = new String[2];
		try {
			ApplicantBean applicantBean = entityManager.find(ApplicantBean.class, applicationId);
			info[0]=applicantBean.getEmailId();
			info[1]=applicantBean.getProgramsScheduledBean().getProgramId();
		} catch (Exception e) {
			throw new UserException("No applicant found with id : "+applicationId);
		}
		 return info;
	}

}