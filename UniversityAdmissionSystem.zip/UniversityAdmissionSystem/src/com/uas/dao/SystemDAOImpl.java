package com.uas.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.uas.bean.ApplicantBean;
import com.uas.bean.Application_Status;
import com.uas.bean.ParticipantBean;
import com.uas.bean.ProgramsOfferedBean;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.bean.UserBean;
import com.uas.exception.UserException;


/**
 *  Author 		: Gaurav, Pratyush, Arjun
 *  Class Name 	: SystemDAOImpl 
 *  Package 	: com.uas.dao 
 *  Date 		: December 09, 2017
 *  Version		: 1.0.1
 */
@Repository
@Transactional
public class SystemDAOImpl implements ISystemDAO {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	/**************************************************************
	 * - Method Name : isAuthenticated(UserBean userBean) 
	 * - Input Parameters :  UserBean userBean
	 * - Return Type :boolean 
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 09, 2017 
	 * - Description : Authenticate the user
	 * - Version	: 1.0.1
	 *************************************************************/
	@Override
	public UserBean isAuthenticated(UserBean userBean) throws UserException {
		UserBean users = null;
		try {
			users = entityManager.find(UserBean.class, userBean.getLoginId());
		} catch (Exception e) {
			throw new UserException("Invalid Login Credentials");
		}		
		return users;
	}

	/****************************************************************************
	 * - Method Name 		: deleteProgramOffered(String programName)
	 * - Input Parameters 	: String programName
	 * - Return Type 		: boolean 
	 * - Throws 			: UserException 
	 * - Author 			: Gaurav, Pratyush, Arjun
	 * - Creation Date 		: December 09, 2017 
	 * - Description 		: delete program offered according to program name
	 * - Version			: 1.0.1
	 ****************************************************************************/
	@Override
	public boolean deleteProgramOffered(String programName)
			throws UserException {

		ProgramsOfferedBean programsOfferedBean = null;
		boolean isDeleted = false;
		try {
			programsOfferedBean = entityManager.find(ProgramsOfferedBean.class, programName);
			entityManager.remove(programsOfferedBean);
			isDeleted=true;
		} catch (Exception e) {
			throw new UserException("No program exist with this name : "+programName);
		}
		
		return isDeleted;
	}

	/**************************************************************
	 * - Method Name : addProgramOffered(ProgramsOfferedBean programsOfferedBean)
	 * - Input Parameters :  ProgramsOfferedBean programsOfferedBean
	 * - Return Type :boolean 
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 09, 2017 
	 * - Description : insert program offered
	 * - Version	: 1.0.1 
	 *************************************************************/
	@Override
	public boolean addProgramOffered(ProgramsOfferedBean programsOfferedBean)
			throws UserException {
		boolean isInserted = false;
		try {
			entityManager.persist(programsOfferedBean);
			entityManager.flush();
			isInserted = true;
		} catch (Exception e) {
			throw new UserException("Invalid Data");
		}
		return isInserted;
	}

	/**************************************************************
	 * - Method Name : viewProgramsScheduled()
	 * - Input Parameters :  
	 * - Return Type : List<ProgramsScheduledBean>
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 09, 2017 
	 * - Description : Retrieve all programs scheduled
	 * - Version : 1.0.1
	 *************************************************************/
	@Override
	public List<ProgramsScheduledBean> viewProgramsScheduled()
			throws UserException {
		List<ProgramsScheduledBean> programScheduledList = null;
		try {
			TypedQuery<ProgramsScheduledBean> query = entityManager.createQuery("FROM ProgramsScheduledBean", ProgramsScheduledBean.class);
			programScheduledList = query.getResultList();
		} catch (Exception e) {
			throw new UserException("No data found");
		}
		
		
		return programScheduledList;
	}

	/**************************************************************
	 * - Method Name : deleteProgramScheduled(String programId)
	 * - Input Parameters :  String programId
	 * - Return Type : boolean
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 09, 2017 
	 * - Description : delete programs scheduled according to program ID
	 * - Version : 1.0.1
	 *************************************************************/
	@Override
	public boolean deleteProgramScheduled(String programId)
			throws UserException {

		ProgramsScheduledBean programsScheduledBean = null;
		boolean isDeleted = false;
		try {
			programsScheduledBean = entityManager.find(ProgramsScheduledBean.class, programId);
			entityManager.remove(programsScheduledBean);
			isDeleted=true;
		} catch (Exception e) {
			throw new UserException("No program exist with this id : "+programId);
		}
		
		return isDeleted;

	}

	/**************************************************************
	 * - Method Name : addProgramScheduled(ProgramsScheduledBean programsScheduledBean)
	 * - Input Parameters :  ProgramsScheduledBean programsScheduledBean
	 * - Return Type : boolean
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 09, 2017 
	 * - Description : insert new programs scheduled
	 * - Version : 1.0.1 
	 *************************************************************/
	@Override
	public boolean addProgramScheduled(
			ProgramsScheduledBean programsScheduledBean) throws UserException {
		boolean isInserted = false;
		try {
			entityManager.persist(programsScheduledBean);
			entityManager.flush();
			isInserted = true;
		} catch (Exception e) {
			throw new UserException("Invalid Data");
		}
		return isInserted;
	}

	/**************************************************************
	 * - Method Name : viewListOfApplicants()
	 * - Input Parameters :  
	 * - Return Type : List<ApplicantBean>
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 09, 2017 
	 * - Description : Retrieve list of applicants
	 * - Version : 1.0.1
	 *************************************************************/
	@Override
	public List<ApplicantBean> viewListOfApplicants() throws UserException {

		List<ApplicantBean> applicantList = null;
		try {
			TypedQuery<ApplicantBean> query = entityManager.createQuery("FROM ApplicantBean", ApplicantBean.class);
			applicantList = query.getResultList();
		} catch (Exception e) {
			throw new UserException("No data found");
		}
	
		return applicantList;
	}
	
	/**************************************************************
	 * - Method Name : viewListOfApplicants(String Scheduled_program_id)
	 * - Input Parameters : String Scheduled_program_id 
	 * - Return Type :List<ApplicantBean>
	 * - Throws : UserException 
	 * - Author : Jitesh, Harshita, Sree Ramya
	 * - Creation Date : December 09, 2017 
	 * - Description : Retrieve list of applicants based on scheduled program ID
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public List<ApplicantBean> viewListOfApplicants(String Scheduled_program_id)
			throws UserException{
		List<ApplicantBean> applicantBean = null;
		try {
			TypedQuery<ApplicantBean> query = entityManager.createQuery("FROM ApplicantBean WHERE Scheduled_program_id=?", ApplicantBean.class);
			query.setParameter(1, Scheduled_program_id);
			applicantBean = query.getResultList();
		} catch (Exception e) {
			throw new UserException("No Applicant Exist");
		}
		return applicantBean;
		
	}

	/**************************************************************
	 * - Method Name : scheduleInterviewDate(int applicationId,Application_Status status, LocalDate dateOfInterview)
	 * - Input Parameters : int applicationId,Application_Status status, LocalDate dateOfInterview
	 * - Return Type :boolean
	 * - Throws : UserException 
	 * - Author : Jitesh, Harshita, Sree Ramya
	 * - Creation Date : December 09, 2017 
	 * - Description : update status of applicant and assign date of interview to the applicant
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public boolean scheduleInterviewDate(int applicationId,Application_Status status, Date dateOfInterview)
			throws UserException {
		boolean isUpdated = false;
		try {
			ApplicantBean applicantBean = entityManager.find(ApplicantBean.class, applicationId);
			applicantBean.setStatus(status);
			applicantBean.setDateOfInterview(dateOfInterview);
			entityManager.merge(applicantBean);
			isUpdated = true;
		} catch (Exception e) {
			throw new UserException("No Applicant exist with this Id : "+applicationId);
		}
		return isUpdated;
	}

	/**************************************************************
	 * - Method Name : getAllProgramsSchedule()
	 * - Input Parameters :
	 * - Return Type :List<ProgramsScheduledBean>
	 * - Throws : UserException 
	 * - Author : Jitesh, Harshita, Sree Ramya
	 * - Creation Date : December 09, 2017 
	 * - Description : retrieve all programs scheduled
	 * - Version : 1.0
	 *************************************************************/

	@Override
	public List<ProgramsScheduledBean> getAllProgramsSchedule()
			throws UserException {
		List<ProgramsScheduledBean> programList = null;
		try {
			TypedQuery<ProgramsScheduledBean> query = entityManager.createQuery("FROM ProgramsScheduledBean",ProgramsScheduledBean.class);
			programList = query.getResultList();
		} catch (Exception e) {
			throw new UserException("No Program Exists ");
		}
		return programList;
	}
	
	/**************************************************************
	 * - Method Name : viewPrograms() 
	 * - Input Parameters :  
	 * - Return Type :List<ProgramsScheduledBean> 
	 * - Throws : UserException 
	 * - Author : KAMAL, GUNJAN
	 * - Creation Date : December 09, 2017 
	 * - Description : Retrieval of programs offered along with programs scheduled
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public List<ProgramsScheduledBean> viewPrograms() throws UserException {
		List<ProgramsScheduledBean> programScheduledList = null;
		try {
			TypedQuery<ProgramsScheduledBean> query = entityManager.createQuery("FROM ProgramsScheduledBean", ProgramsScheduledBean.class);
			programScheduledList = query.getResultList();
		} catch (Exception e) {
			throw new UserException("No data found");
		}
		
		return programScheduledList;
	}

	
	/**************************************************************
	 * - Method Name : insertApplicant(ApplicantBean applicantBean,String programName) 
	 * - Input Parameters :  ApplicantBean, String
	 * - Return Type :int 
	 * - Throws : UserException 
	 * - Author : KAMAL, GUNJAN
	 * - Creation Date : December 09, 2017 
	 * - Description : insert new applicant details
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public int insertApplicant(ApplicantBean applicantBean,String programId) throws UserException {
		int id = 0;
		try {
			TypedQuery<ProgramsScheduledBean> query = entityManager.createQuery("FROM ProgramsScheduledBean WHERE Scheduled_program_id=?",ProgramsScheduledBean.class);
			query.setParameter(1, programId);
			ProgramsScheduledBean programsScheduledBean  = query.getSingleResult();
			applicantBean.setProgramsScheduledBean(programsScheduledBean);
			entityManager.persist(applicantBean);
			entityManager.flush();
			id = applicantBean.getApplicationId();
		} catch (Exception e) {
			throw new UserException("Unable to persist ");
		}
		return id;
	}

	
	/**************************************************************
	 * - Method Name : viewStatus(int applicantId) 
	 * - Input Parameters :  int
	 * - Return Type :Application_Status 
	 * - Throws : UserException 
	 * - Author : KAMAL, GUNJAN
	 * - Creation Date : December 09, 2017 
	 * - Description : Retrieval of status of an applicant according to applicantId
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public Application_Status viewStatus(int applicantId) throws UserException {
		
		Application_Status status = null;
		
		try {
			ApplicantBean applicantBean = entityManager.find(ApplicantBean.class, applicantId);
			status = applicantBean.getStatus();
		} catch (Exception e) {
			throw new UserException("No applicant found with this id : "+applicantId);
		}
		return status;
	}


	/**************************************************************
	 * - Method Name : getApplicantInfo(int applicationId) 
	 * - Input Parameters :  int applicationId
	 * - Return Type :String[] 
	 * - Throws : UserException 
	 * - Author : KAMAL, GUNJAN
	 * - Creation Date : December 09, 2017 
	 * - Description : Retrieval of email id and scheduled program id of an applicant according to applicantId
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public String[] getApplicantInfo(int applicationId) throws UserException {
		
		String[] info  = new String[2];
		try {
			ApplicantBean applicantBean = entityManager.find(ApplicantBean.class, applicationId);
			info[0]=applicantBean.getEmailId();
			info[1]=applicantBean.getProgramsScheduledBean().getProgramId();
		} catch (Exception e) {
			throw new UserException("No applicant found with id : "+applicationId);
		}
		 return info;
	}
	
	/**************************************************************
	 * - Method Name : addParticipant(ParticipantBean participantBean, int applicationId, int scheduleId)
	 * - Input Parameters : ParticipantBean participantBean, int applicationId, int scheduleId
	 * - Return Type :boolean
	 * - Throws : UserException 
	 * - Author : Jitesh, Harshita, Sree Ramya
	 * - Creation Date : December 09, 2017 
	 * - Description : insert applicant to the participant table
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public boolean addParticipant(ParticipantBean participantBean, int applicationId, String scheduleId) throws UserException {
		boolean isInserted = false;
		ProgramsScheduledBean programsScheduledBean = new ProgramsScheduledBean();
		programsScheduledBean.setProgramId(scheduleId);
		ApplicantBean applicantBean = new ApplicantBean();
		applicantBean.setApplicationId(applicationId);
		participantBean.setProgramsScheduledBean(programsScheduledBean);
		participantBean.setApplicantBean(applicantBean);
		try {
			entityManager.persist(programsScheduledBean);
			isInserted=true;
		} catch (Exception e) {
			throw new UserException("Unable to persist");
		}
		
		return isInserted;
	}
}