package com.uas.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uas.bean.ApplicantBean;
import com.uas.bean.Application_Status;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.bean.UserBean;
import com.uas.dao.ISystemDAO;
import com.uas.exception.UserException;

/**
 *  Author : Jitesh, Harshita, Sree Ramya
 *  Class Name : MacServiceImpl 
 *  Package :com.uas.service 
 *  Date : December 09, 2017
 *  Version: 1.0 
 */
@Service
public class MacServiceImpl implements IMacService {

	@Autowired
	private ISystemDAO macDao;
	
	@Autowired
	private IParticipantService participantService;
	/**************************************************************
	 * - Method Name : isAuthenticated(UserBean userBean) 
	 * - Input Parameters : UserBean userBean 
	 * - Return Type :boolean 
	 * - Throws : UserException 
	 * - Author : Jitesh, Harshita, Sree Ramya
	 * - Creation Date : December 09, 2017 
	 * - Description : Authenticate the user
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public boolean isAuthenticated(UserBean userBean)
			throws UserException {
		boolean isMatched = false;
		UserBean user = macDao.isAuthenticated(userBean);
		
		if(user.getPassword().equals(userBean.getPassword())){
			if(user.getRole().equals(userBean.getRole())){
				if(user.getLoginId().equals(userBean.getLoginId())){
					isMatched = true;
				}
			}			
		}
		return isMatched;
				
	}

	/**************************************************************
	 * - Method Name : viewAllStudentDetails(String Scheduled_program_id)
	 * - Input Parameters : String Scheduled_program_id 
	 * - Return Type :List<ApplicantBean>
	 * - Throws : UserException 
	 * - Author : Jitesh, Harshita, Sree Ramya
	 * - Creation Date : December 09, 2017 
	 * - Description : Retrieve list of applicants based on scheduled program ID
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public List<ApplicantBean> viewAllStudentDetails(String Scheduled_program_id) throws UserException{
		List<ApplicantBean> applicantList = macDao.viewListOfApplicants(Scheduled_program_id);
		List<ApplicantBean> validApplicantList = new ArrayList<>();
		for (ApplicantBean applicantBean : applicantList) {
			if(applicantBean.getMarksObtained()>=Integer.parseInt(applicantBean.getProgramsScheduledBean().getProgramsOfferedBean().getApplicantEligibility())){
				validApplicantList.add(applicantBean);
			}
		}
		return validApplicantList;
	}

	/**************************************************************
	 * - Method Name : scheduleInterviewDate(int applicationId,Application_Status status, LocalDate dateOfInterview)
	 * - Input Parameters : int applicationId,Application_Status status, LocalDate dateOfInterview
	 * - Return Type :boolean
	 * - Throws : UserException 
	 * - Author : Jitesh, Harshita, Sree Ramya
	 * - Creation Date : December 09, 2017 
	 * - Description : update status of applicant and assign date of interview to the applicant
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public boolean scheduleInterviewDate(int applicationId, Application_Status status, Date dateOfInterview) throws UserException{
		return macDao.scheduleInterviewDate(applicationId, status, dateOfInterview);
	}

	
	/**************************************************************
	 * - Method Name : getAllProgramsSchedule()
	 * - Input Parameters :
	 * - Return Type :List<ProgramsScheduledBean>
	 * - Throws : UserException 
	 * - Author : Jitesh, Harshita, Sree Ramya
	 * - Creation Date : December 09, 2017 
	 * - Description : retrieve all programs scheduled
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public List<ProgramsScheduledBean> getAllProgramsSchedule()
			throws UserException {
		return macDao.getAllProgramsSchedule();
	}

}