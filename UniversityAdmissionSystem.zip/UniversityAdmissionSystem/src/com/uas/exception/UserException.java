package com.uas.exception;

/**
 *  Author : Jitesh, Harshita, Sree Ramya
 *  Class Name : UserException 
 *  Package :com.uas.exception
 *  Date : November 27, 2017
 *  Version : 1.0
 */

public class UserException extends Exception {

	private static final long serialVersionUID = 5168136240377046837L;

	public UserException(String message) {
		super(message);
	}
	
}