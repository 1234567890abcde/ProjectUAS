package com.uas.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Author : KAMAL, GUNJAN 
 * Class Name : UserBean 
 * Package : com.uas.bean 
 * Date : November 27, 2017 
 * Version : 1.1
 */
@Entity
@Table(name = "Users")
public class UserBean {

	@Id
	@Column(name = "login_id", length=5)
	private String loginId;

	@Column(name = "password", length = 10)
	private String password;

	@Column(name = "role")
	@Enumerated(EnumType.STRING)
	private UserRole role;

	// Constructors
	public UserBean() {
		super();
	}

	public UserBean(String loginId, String password, UserRole role) {
		super();
		this.loginId = loginId;
		this.password = password;
		this.role = role;
	}

	// Getters and Setters
	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public UserRole getRole() {
		return role;
	}

	public void setRole(UserRole role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "UserBean [loginId=" + loginId + ", password=" + password
				+ ", role=" + role + "]";
	}

	
}