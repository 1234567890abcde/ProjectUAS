package com.uas.bean;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Author : KAMAL, GUNJAN 
 * Class Name : ProgramsScheduledBean 
 * Package : com.uas.bean 
 * Date : November 27, 2017 
 * Version : 1.1
 */
@Entity
@Table(name = "Programs_Scheduled")
public class ProgramsScheduledBean {

	@Id
	@Column(name = "Scheduled_program_id", length = 5)
	private String programId;

	@Column(name = "City", length = 20)
	private String city;

	@Column(name = "State", length = 20)
	private String state;

	@Column(name = "Zipcode")
	private int zipCode;

	@Column(name = "start_date")
	@Temporal(TemporalType.DATE)
	private Date startDate;

	@Column(name = "end_date")
	@Temporal(TemporalType.DATE)
	private Date endDate;

	@Column(name = "sessions_per_week")
	private byte sessionPerWeek;

	@ManyToOne
	@JoinColumn(name = "ProgramName")
	private ProgramsOfferedBean programsOfferedBean;

	@OneToMany(mappedBy="programsScheduledBean",cascade=CascadeType.ALL)
	private Set<ApplicantBean> applicantBean = new HashSet<>();

	@OneToMany(mappedBy="programsScheduledBean",cascade=CascadeType.ALL)
	private Set<ParticipantBean> participantBean = new HashSet<>();
	// Constructors
	public ProgramsScheduledBean() {
		super();
	}
	public ProgramsScheduledBean(String programId, String city, String state,
			int zipCode, Date startDate, Date endDate, byte sessionPerWeek,
			ProgramsOfferedBean programsOfferedBean,
			Set<ApplicantBean> applicantBean,
			Set<ParticipantBean> participantBean) {
		super();
		this.programId = programId;
		this.city = city;
		this.state = state;
		this.zipCode = zipCode;
		this.startDate = startDate;
		this.endDate = endDate;
		this.sessionPerWeek = sessionPerWeek;
		this.programsOfferedBean = programsOfferedBean;
		this.applicantBean = applicantBean;
		this.participantBean = participantBean;
	}
	
	
	public ProgramsScheduledBean(String programId, String city, String state,
			int zipCode, Date startDate, Date endDate, byte sessionPerWeek) {
		super();
		this.programId = programId;
		this.city = city;
		this.state = state;
		this.zipCode = zipCode;
		this.startDate = startDate;
		this.endDate = endDate;
		this.sessionPerWeek = sessionPerWeek;
	}
	public String getProgramId() {
		return programId;
	}
	public void setProgramId(String programId) {
		this.programId = programId;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getZipCode() {
		return zipCode;
	}
	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public byte getSessionPerWeek() {
		return sessionPerWeek;
	}
	public void setSessionPerWeek(byte sessionPerWeek) {
		this.sessionPerWeek = sessionPerWeek;
	}
	public ProgramsOfferedBean getProgramsOfferedBean() {
		return programsOfferedBean;
	}
	public void setProgramsOfferedBean(ProgramsOfferedBean programsOfferedBean) {
		this.programsOfferedBean = programsOfferedBean;
	}
	public Set<ApplicantBean> getApplicantBean() {
		return applicantBean;
	}
	public void setApplicantBean(Set<ApplicantBean> applicantBean) {
		this.applicantBean = applicantBean;
	}
	public Set<ParticipantBean> getParticipantBean() {
		return participantBean;
	}
	public void setParticipantBean(Set<ParticipantBean> participantBean) {
		this.participantBean = participantBean;
	}

	public void addApplicant(ApplicantBean applicantBean){
		applicantBean.setProgramsScheduledBean(this);
		this.getApplicantBean().add(applicantBean);
	}

	public void addParticipant(ParticipantBean participantBean){
		participantBean.setProgramsScheduledBean(this);
		this.getParticipantBean().add(participantBean);
	}
}
